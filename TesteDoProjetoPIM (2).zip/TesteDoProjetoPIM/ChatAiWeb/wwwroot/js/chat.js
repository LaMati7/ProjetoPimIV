(() => {
    const input = document.getElementById('input');
    const send = document.getElementById('send');
    const messages = document.getElementById('messages');
    const historyList = document.getElementById('history');

    function appendMessage(text, cls = 'message'){
        const el = document.createElement('div');
        el.className = cls;
        el.textContent = text;
        messages.appendChild(el);
        messages.scrollTop = messages.scrollHeight;
    }

    function clearMessages(){
        messages.innerHTML = '';
    }

    async function sendMessage(text){
        appendMessage(text, 'message user');
        appendMessage('...', 'message');
        try{
            const res = await fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: text })
            });
            const idx = Array.from(messages.children).length - 1;
            if (!res.ok){
                const err = await res.text();
                messages.children[idx].textContent = 'Erro: ' + err;
                return;
            }
            const data = await res.json();
            messages.children[idx].textContent = data.reply || 'Sem resposta';
        }catch(e){
            const idx = Array.from(messages.children).length - 1;
            messages.children[idx].textContent = 'Erro: ' + e.message;
        }
    }

    send.addEventListener('click', ()=>{
        const v = input.value.trim();
        if(!v) return;
        input.value = '';
        sendMessage(v);
    });

    input.addEventListener('keydown', (e)=>{
        if(e.key === 'Enter'){
            send.click();
        }
    });

    // ── Histórico: busca e renderiza entradas do backend ──────────────────
    async function loadHistory(){
        if (!historyList) return;
        historyList.innerHTML = '<li>Carregando...</li>';
        try{
            const res = await fetch('/api/chat/history?limit=100', { method: 'GET' });
            if (!res.ok){
                historyList.innerHTML = '<li>Erro ao carregar histórico</li>';
                return;
            }
            const items = await res.json();
            historyList.innerHTML = '';
            if (!items || items.length === 0){
                historyList.innerHTML = '<li>Nenhum histórico encontrado</li>';
                return;
            }

            items.forEach(entry => {
                const li = document.createElement('li');
                li.className = 'history-entry';
                const created = new Date(entry.createdAt).toLocaleString();
                const short = entry.userMessage.length > 80 ? entry.userMessage.slice(0,77) + '...' : entry.userMessage;
                li.textContent = `${created} — ${short}`;
                li.dataset.message = entry.userMessage;
                li.dataset.reply = entry.aiReply;
                li.addEventListener('click', ()=>{
                    // Ao clicar, limpa e mostra a conversa selecionada
                    clearMessages();
                    appendMessage(entry.userMessage, 'message user');
                    appendMessage(entry.aiReply, 'message');
                });
                historyList.appendChild(li);
            });
        }catch(e){
            historyList.innerHTML = `<li>Erro: ${e.message}</li>`;
        }
    }

    // Carrega histórico ao iniciar
    document.addEventListener('DOMContentLoaded', ()=>{
        loadHistory();
    });
})();
