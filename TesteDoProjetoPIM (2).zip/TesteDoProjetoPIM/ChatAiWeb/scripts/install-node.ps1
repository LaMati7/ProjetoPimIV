<#
PowerShell helper: detect Node.js, install via winget if missing, and validate that node/npm are available.
Usage:
  - Open PowerShell (recommended: Run as Administrator)
  - cd to this script folder and run:
      powershell -ExecutionPolicy Bypass -File .\install-node.ps1

What the script does:
 1. Checks for `node` and `npm`. If present prints versions and exits.
 2. If missing, checks for `winget`. If winget exists, offers to install Node LTS via winget (automated).
 3. If winget is not available, offers to open the Node.js download page and the nvm-windows release page.

This script is interactive and asks for confirmation before installing.
#>

Set-StrictMode -Version Latest

function Test-CommandExists {
    param([string]$Name)
    return (Get-Command $Name -ErrorAction SilentlyContinue) -ne $null
}

function Show-VersionsIfPresent {
    try {
        if (Test-CommandExists node) {
            Write-Host "node version: $(node -v)" -ForegroundColor Green
        }
        if (Test-CommandExists npm) {
            Write-Host "npm version: $(npm -v)" -ForegroundColor Green
        }
    } catch {
        # ignore
    }
}

Write-Host "Checking for Node.js..." -ForegroundColor Cyan
if (Test-CommandExists node) {
    Write-Host "Node is already installed." -ForegroundColor Green
    Show-VersionsIfPresent
    exit 0
}

Write-Host "Node.js not found on PATH." -ForegroundColor Yellow

$hasWinget = Test-CommandExists winget
if ($hasWinget) {
    Write-Host "winget detected on this machine." -ForegroundColor Cyan
    $install = Read-Host "Install Node.js LTS using winget now? (Y/N)"
    if ($install -match '^[Yy]') {
        Write-Host "Installing Node.js LTS via winget..." -ForegroundColor Cyan
        try {
            # Use automated flags to accept agreements
            $args = @('install','OpenJS.NodeJS.LTS','-e','--source','winget','--accept-package-agreements','--accept-source-agreements')
            $proc = Start-Process -FilePath winget -ArgumentList $args -NoNewWindow -Wait -PassThru
            if ($proc.ExitCode -eq 0) {
                Write-Host "winget reported success. Verifying installation..." -ForegroundColor Green
                Start-Sleep -Seconds 2
                # reload PATH for current session: try to find node.exe in Program Files
                $possible = 'C:\Program Files\nodejs','C:\Program Files (x86)\nodejs'
                foreach ($p in $possible) {
                    if (Test-Path (Join-Path $p 'node.exe')) {
                        $env:Path = $env:Path + ";$p"
                    }
                }
                if (Test-CommandExists node) {
                    Show-VersionsIfPresent
                    Write-Host "Node install complete." -ForegroundColor Green
                    exit 0
                } else {
                    Write-Host "Node executable not found in PATH yet. Try closing and reopening PowerShell, then run `node -v`." -ForegroundColor Yellow
                    exit 1
                }
            } else {
                Write-Host "winget install failed with exit code $($proc.ExitCode)." -ForegroundColor Red
                exit 1
            }
        } catch {
            Write-Host "Failed to run winget: $($_.Exception.Message)" -ForegroundColor Red
            exit 1
        }
    } else {
        Write-Host "Skipping winget install." -ForegroundColor Yellow
    }
} else {
    Write-Host "winget not found on this system." -ForegroundColor Yellow
}

Write-Host "Options if winget is not available or you chose not to use it:" -ForegroundColor Cyan
Write-Host "1) Download and run the official Node.js installer (LTS) from https://nodejs.org/en/" -ForegroundColor White
Write-Host "2) Install nvm-windows (good for managing multiple Node versions): https://github.com/coreybutler/nvm-windows/releases" -ForegroundColor White
Write-Host "3) Use Chocolatey if you have it: choco install nodejs-lts -y" -ForegroundColor White

$choice = Read-Host "Open Node.js download page in browser now? (Y/N)"
if ($choice -match '^[Yy]') {
    Start-Process 'https://nodejs.org/en/download/'
    Write-Host "Opened browser to Node.js downloads. Follow the installer GUI, then re-open PowerShell and run 'node -v' to confirm." -ForegroundColor Green
} else {
    Write-Host "No action taken. When Node is installed, run this script again or run 'node -v' to confirm." -ForegroundColor Yellow
}

exit 0
