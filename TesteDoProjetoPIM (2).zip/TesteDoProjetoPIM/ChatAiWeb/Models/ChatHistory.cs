namespace ChatAiWeb.Models;

public class ChatHistory
{
    public int Id { get; set; }
    public string UserName { get; set; } = string.Empty;
    public string UserMessage { get; set; } = string.Empty;
    public string AiReply { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
