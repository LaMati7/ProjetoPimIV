using Microsoft.Data.Sqlite;
using ChatAiWeb.Models;

namespace ChatAiWeb.Repositories;

public interface IChatHistoryRepository
{
    Task SaveAsync(ChatHistory entry);
    Task<IEnumerable<ChatHistory>> GetByUserAsync(string userName, int limit = 50);
    Task<IEnumerable<ChatHistory>> GetAllAsync(int limit = 100);
}

public class ChatHistoryRepository : IChatHistoryRepository
{
    private readonly string _connectionString;

    public ChatHistoryRepository(IConfiguration configuration)
    {
        // Pega o caminho do banco do appsettings.json ou usa o padrão
        var dbPath = configuration["Database:Path"] ?? "chat_history.db";
        _connectionString = $"Data Source={dbPath}";
    }

    // ── Salva uma mensagem e sua resposta ────────────────────────────────────
    public async Task SaveAsync(ChatHistory entry)
    {
        await using var conn = new SqliteConnection(_connectionString);
        await conn.OpenAsync();

        var cmd = conn.CreateCommand();
        cmd.CommandText = """
            INSERT INTO ChatHistory (UserName, UserMessage, AiReply, CreatedAt)
            VALUES ($userName, $userMessage, $aiReply, $createdAt)
            """;

        cmd.Parameters.AddWithValue("$userName",    entry.UserName);
        cmd.Parameters.AddWithValue("$userMessage", entry.UserMessage);
        cmd.Parameters.AddWithValue("$aiReply",     entry.AiReply);
        cmd.Parameters.AddWithValue("$createdAt",   entry.CreatedAt.ToString("o")); // ISO 8601

        await cmd.ExecuteNonQueryAsync();
    }

    // ── Busca histórico de um usuário específico ─────────────────────────────
    public async Task<IEnumerable<ChatHistory>> GetByUserAsync(string userName, int limit = 50)
    {
        await using var conn = new SqliteConnection(_connectionString);
        await conn.OpenAsync();

        var cmd = conn.CreateCommand();
        cmd.CommandText = """
            SELECT Id, UserName, UserMessage, AiReply, CreatedAt
            FROM   ChatHistory
            WHERE  UserName = $userName
            ORDER  BY CreatedAt DESC
            LIMIT  $limit
            """;

        cmd.Parameters.AddWithValue("$userName", userName);
        cmd.Parameters.AddWithValue("$limit",    limit);

        return await ReadRowsAsync(cmd);
    }

    // ── Busca histórico geral (todos os usuários) ────────────────────────────
    public async Task<IEnumerable<ChatHistory>> GetAllAsync(int limit = 100)
    {
        await using var conn = new SqliteConnection(_connectionString);
        await conn.OpenAsync();

        var cmd = conn.CreateCommand();
        cmd.CommandText = """
            SELECT Id, UserName, UserMessage, AiReply, CreatedAt
            FROM   ChatHistory
            ORDER  BY CreatedAt DESC
            LIMIT  $limit
            """;

        cmd.Parameters.AddWithValue("$limit", limit);

        return await ReadRowsAsync(cmd);
    }

    // ── Leitura genérica de linhas ───────────────────────────────────────────
    private static async Task<IEnumerable<ChatHistory>> ReadRowsAsync(SqliteCommand cmd)
    {
        var results = new List<ChatHistory>();
        await using var reader = await cmd.ExecuteReaderAsync();

        while (await reader.ReadAsync())
        {
            results.Add(new ChatHistory
            {
                Id          = reader.GetInt32(0),
                UserName    = reader.GetString(1),
                UserMessage = reader.GetString(2),
                AiReply     = reader.GetString(3),
                CreatedAt   = DateTime.Parse(reader.GetString(4))
            });
        }

        return results;
    }
}
