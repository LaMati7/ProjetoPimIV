using Microsoft.Data.Sqlite;

namespace ChatAiWeb.Data;

/// <summary>
/// Cria o banco SQLite e a tabela ChatHistory na inicialização da aplicação,
/// caso ainda não existam.
/// </summary>
public static class DatabaseInitializer
{
    public static void Initialize(IConfiguration configuration)
    {
        var dbPath = configuration["Database:Path"] ?? "chat_history.db";
        var connectionString = $"Data Source={dbPath}";

        using var conn = new SqliteConnection(connectionString);
        conn.Open();

        var cmd = conn.CreateCommand();
        cmd.CommandText = """
            CREATE TABLE IF NOT EXISTS ChatHistory (
                Id          INTEGER PRIMARY KEY AUTOINCREMENT,
                UserName    TEXT    NOT NULL,
                UserMessage TEXT    NOT NULL,
                AiReply     TEXT    NOT NULL,
                CreatedAt   TEXT    NOT NULL   -- ISO 8601, e.g. 2026-03-31T14:00:00.000Z
            );

            -- Índice para buscas por usuário (opcional mas recomendado)
            CREATE INDEX IF NOT EXISTS idx_chathistory_username
                ON ChatHistory (UserName);
            """;

        cmd.ExecuteNonQuery();
    }
}
