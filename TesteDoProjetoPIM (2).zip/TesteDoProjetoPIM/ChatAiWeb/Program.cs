using Microsoft.AspNetCore.Authentication.Cookies;
using ChatAiWeb.Data;
using ChatAiWeb.Repositories;

var builder = WebApplication.CreateBuilder(args);

// ── Serviços ─────────────────────────────────────────────────────────────────
builder.Services.AddControllersWithViews().AddRazorRuntimeCompilation();
builder.Services.AddHttpClient();

// Repositório de histórico do chat
builder.Services.AddScoped<IChatHistoryRepository, ChatHistoryRepository>();

// Authentication (cookie) - simple scheme for admin user
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath    = "/Account/Login";
        options.Cookie.HttpOnly = true;
    });
builder.Services.AddAuthorization();

var app = builder.Build();

// ── Inicializa o banco de dados SQLite ───────────────────────────────────────
DatabaseInitializer.Initialize(app.Configuration);

// ── Pipeline HTTP ─────────────────────────────────────────────────────────────
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}

app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name:    "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
