using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using ChatAiWeb.Models;
using ChatAiWeb.Repositories;

namespace ChatAiWeb.Controllers;

[Authorize]
public class ChatController : Controller
{
    private readonly IHttpClientFactory       _httpClientFactory;
    private readonly IChatHistoryRepository   _history;

    public ChatController(IHttpClientFactory httpClientFactory,
                          IChatHistoryRepository history)
    {
        _httpClientFactory = httpClientFactory;
        _history           = history;
    }

    public IActionResult Index() => View();

    // ── GET /api/chat/history  (histórico do usuário logado) ─────────────────
    [HttpGet]
    [Route("api/chat/history")]
    public async Task<IActionResult> GetHistory([FromQuery] int limit = 50)
    {
        var userName = User.Identity?.Name ?? "anonymous";
        var entries  = await _history.GetByUserAsync(userName, limit);
        return Ok(entries);
    }

    // ── POST /api/chat  (envia mensagem e salva no histórico) ─────────────────
    [HttpPost]
    [Route("api/chat")]
    public async Task<IActionResult> Post([FromBody] ChatRequest req)
    {
        if (req is null || string.IsNullOrWhiteSpace(req.Message))
            return BadRequest(new { error = "Request body must include a 'message' field." });

        var userName = User.Identity?.Name ?? "anonymous";
        string? reply = null;

        // ── Modo mock para testes sem chave ──────────────────────────────────
        var useMock = Environment.GetEnvironmentVariable("USE_MOCK");
        if (!string.IsNullOrEmpty(useMock) && useMock == "1")
        {
            reply = $"(mock) Recebido: {req.Message}";
            await SaveHistory(userName, req.Message, reply);
            return Ok(new { reply });
        }

        // ── Gemini via API Key ────────────────────────────────────────────────
        var geminiKey = Environment.GetEnvironmentVariable("GEMINI_API_KEY");
        if (!string.IsNullOrEmpty(geminiKey))
        {
            var result = await CallGeminiAsync(geminiKey, req.Message);
            if (result.Error is not null)
                return StatusCode(result.StatusCode, new { error = result.Error });

            reply = result.Reply!;
            await SaveHistory(userName, req.Message, reply);
            return Ok(new { reply });
        }

        // ── Fallback: OpenAI ─────────────────────────────────────────────────
        var openAiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY");
        if (!string.IsNullOrEmpty(openAiKey))
        {
            var result = await CallOpenAiAsync(openAiKey, req.Message);
            if (result.Error is not null)
                return StatusCode(result.StatusCode, new { error = result.Error });

            reply = result.Reply!;
            await SaveHistory(userName, req.Message, reply);
            return Ok(new { reply });
        }

        return StatusCode(500, new
        {
            error = "Nenhuma credencial de IA configurada. Defina GEMINI_API_KEY ou OPENAI_API_KEY."
        });
    }

    // ── Helpers privados ─────────────────────────────────────────────────────

    private async Task SaveHistory(string userName, string userMessage, string aiReply)
    {
        try
        {
            await _history.SaveAsync(new ChatHistory
            {
                UserName    = userName,
                UserMessage = userMessage,
                AiReply     = aiReply,
                CreatedAt   = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            // Não quebra o fluxo principal se o banco falhar
            Console.Error.WriteLine($"[ChatHistory] Erro ao salvar: {ex.Message}");
        }
    }

    private async Task<(string? Reply, string? Error, int StatusCode)> CallGeminiAsync(
        string apiKey, string message)
    {
        var client = _httpClientFactory.CreateClient();
        var url    = $"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={apiKey.Trim()}";

        var payload = new
        {
            contents = new[]
            {
                new { parts = new[] { new { text = message } } }
            }
        };

        var content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

        try
        {
            var res  = await client.PostAsync(url, content);
            var body = await res.Content.ReadAsStringAsync();

            if (!res.IsSuccessStatusCode)
                return (null, body, (int)res.StatusCode);

            using var doc = JsonDocument.Parse(body);
            string? reply = null;

            if (doc.RootElement.TryGetProperty("candidates", out var candidates)
                && candidates.GetArrayLength() > 0)
            {
                var first = candidates[0];
                if (first.TryGetProperty("content",  out var contentEl)
                    && contentEl.TryGetProperty("parts", out var parts)
                    && parts.GetArrayLength() > 0)
                {
                    reply = parts[0].GetProperty("text").GetString();
                }
            }

            return (reply ?? body, null, 200);
        }
        catch (Exception ex)
        {
            return (null, $"Gemini upstream error: {ex.Message}", 500);
        }
    }

    private async Task<(string? Reply, string? Error, int StatusCode)> CallOpenAiAsync(
        string apiKey, string message)
    {
        var client = _httpClientFactory.CreateClient();
        client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", apiKey);
        client.DefaultRequestHeaders.UserAgent.ParseAdd("ChatAiWeb/1.0");

        var payload = new
        {
            model    = "gpt-3.5-turbo",
            messages = new[]
            {
                new { role = "system", content = "Você é um assistente técnico útil e cortês." },
                new { role = "user",   content = message }
            }
        };

        var content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

        try
        {
            var res  = await client.PostAsync("https://api.openai.com/v1/chat/completions", content);
            var body = await res.Content.ReadAsStringAsync();

            if (!res.IsSuccessStatusCode)
                return (null, body, (int)res.StatusCode);

            using var doc = JsonDocument.Parse(body ?? "{}");
            if (!doc.RootElement.TryGetProperty("choices", out var choices)
                || choices.GetArrayLength() == 0)
                return (null, $"No choices returned. Raw: {body}", 500);

            var reply = choices[0].GetProperty("message").GetProperty("content").GetString();
            return (reply, null, 200);
        }
        catch (Exception ex)
        {
            return (null, $"OpenAI upstream error: {ex.Message}", 500);
        }
    }
}

public class ChatRequest
{
    [JsonPropertyName("message")]
    public string Message { get; set; } = string.Empty;
}
