using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace ChatAiWeb.Controllers;

public class AccountController : Controller
{
    // Show login page
    [HttpGet]
    public IActionResult Login(string? message = null)
    {
        if (!string.IsNullOrEmpty(message)) ViewData["Message"] = message;
        return View();
    }

    // Handle login POST - only allow the single admin/admin user
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> LoginPost([FromForm] string username, [FromForm] string password)
    {
        // Simple, intentional: only admin/admin allowed
        if (string.Equals(username?.Trim(), "admin", StringComparison.Ordinal) && string.Equals(password, "admin", StringComparison.Ordinal))
        {
            // Create claims and sign in using cookie authentication
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, "admin"),
                new Claim(ClaimTypes.Role, "Administrator")
            };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);

            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, new AuthenticationProperties
            {
                IsPersistent = true,
                ExpiresUtc = DateTimeOffset.UtcNow.AddDays(1)
            });

            return RedirectToAction("Index", "Home");
        }

        // Invalid credentials
        ViewData["Message"] = "Usuário ou senha inválidos.";
        return View("Login");
    }

    // Disable registration: do not allow creating new users
    [HttpGet]
    public IActionResult Register()
    {
        // Show a page explaining registration is closed and provide link to login
        ViewData["Message"] = "Registro desabilitado. Somente o usuário 'admin' pode acessar.";
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult RegisterPost()
    {
        // Registration is not supported
        return RedirectToAction("Login", new { message = "Registro desabilitado. Use o usuário 'admin'." });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction("Login");
    }
}
