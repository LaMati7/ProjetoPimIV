<#
Create .env from secure input and start the Node backend.
Usage:
  Open PowerShell in this folder and run:
    powershell -ExecutionPolicy Bypass -File .\start-with-env.ps1

What this script does:
  - Checks that `node` and `npm` are available on PATH.
  - Prompts you (securely) for the GEMINI_API_KEY and optional PORT.
  - Writes a `.env` file in the current folder with GEMINI_API_KEY and PORT.
  - If node_modules is missing, runs `npm install`.
  - Starts the server with `npm start` (foreground).

Security notes:
  - The script reads the API key as a SecureString so it isn't shown while typing.
  - The .env file will contain the key in plaintext (required by many Node apps). Do NOT commit .env to version control.
#>

Set-StrictMode -Version Latest

function Test-CommandExists { param([string]$Name) (Get-Command $Name -ErrorAction SilentlyContinue) -ne $null }

if (-not (Test-CommandExists node)) {
    Write-Host "ERROR: 'node' command not found. Install Node.js first (see scripts/install-node.ps1)" -ForegroundColor Red
    exit 1
}

if (-not (Test-CommandExists npm)) {
    Write-Host "ERROR: 'npm' command not found. Install Node.js which includes npm." -ForegroundColor Red
    exit 1
}

# Gather input
Write-Host "This will create a .env file for the Node backend and start the server." -ForegroundColor Cyan
$secure = Read-Host -Prompt "Enter GEMINI_API_KEY (input hidden)" -AsSecureString
if (!$secure) { Write-Host "No key provided. Aborting." -ForegroundColor Yellow; exit 1 }

# Convert SecureString to plain text just for writing to the .env file (zeroed out afterwards)
$ptr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try {
    $gemkey = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($ptr)
} finally {
    [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
}

$portInput = Read-Host -Prompt "Enter PORT (press Enter for default 3000)"
if ([string]::IsNullOrWhiteSpace($portInput)) { $port = 3000 } else { $port = [int]$portInput }

$envFilePath = Join-Path -Path (Get-Location) -ChildPath '.env'
$envContent = "GEMINI_API_KEY=$gemkey`nPORT=$port`n"

try {
    Set-Content -Path $envFilePath -Value $envContent -Encoding ASCII -Force
    Write-Host ".env written to $envFilePath" -ForegroundColor Green
} catch {
    Write-Host "Failed writing .env: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Install dependencies if node_modules missing
if (-not (Test-Path -Path (Join-Path (Get-Location) 'node_modules'))) {
    Write-Host "node_modules not found. Running npm install..." -ForegroundColor Cyan
    $rc = npm install
    if ($LASTEXITCODE -ne 0) {
        Write-Host "npm install failed (exit $LASTEXITCODE). Fix any errors and run this script again." -ForegroundColor Red
        exit $LASTEXITCODE
    }
}

Write-Host "Starting Node server (npm start). Press Ctrl+C to stop." -ForegroundColor Cyan
# Start server in foreground so logs show in this console
npm start
