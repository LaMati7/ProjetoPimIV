const express = require('express');
const axios   = require('axios');
const cors    = require('cors');
require('dotenv').config();

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// ── Endpoint principal ────────────────────────────────────────────────────────
app.post('/api/chat', async (req, res) => {
  const message = req.body?.message;

  if (!message || typeof message !== 'string' || message.trim().length === 0)
    return res.status(400).json({ error: "Request body must include a 'message' field." });

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey)
    return res.status(500).json({ error: 'GEMINI_API_KEY não configurada no servidor.' });

  // Modelo atual: gemini-2.0-flash  |  Endpoint v1beta  |  generateContent
  const url = `curl "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent" \ -H 'Content-Type: application/json' \ -H 'X-goog-api-key: AIzaSyDAjycXITiKHh45O9rcnH6iRWgZ8rccmjw' \ -X POST \ -d '{ "contents": [ { "parts": [ { "text": "Explain how AI works in a few words" } ] } ] }'${apiKey}`;

  // Payload no formato esperado pela API Gemini atual
  const payload = {
    contents: [
      { parts: [{ text: message }] }
    ]
  };

  try {
    const upstream = await axios.post(url, payload, { timeout: 20000 });
    const data = upstream.data;

    // Extrair texto: candidates[0].content.parts[0].text
    const reply = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? null;

    if (reply) return res.json({ reply });
    return res.json({ reply: JSON.stringify(data) });

  } catch (err) {
    if (err.response) {
      return res.status(502).json({
        error: 'Erro na API Gemini',
        status: err.response.status,
        detail: err.response.data
      });
    }
    return res.status(502).json({ error: 'Falha na requisição', detail: err.message });
  }
});

app.get('/health', (_req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log(`✅ Node backend rodando na porta ${PORT}`);
});
