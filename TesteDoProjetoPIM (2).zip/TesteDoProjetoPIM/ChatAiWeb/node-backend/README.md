Node backend to safely use a Gemini API key (avoid exposing keys in the browser).

Quick start (Windows PowerShell)

1. Install dependencies

```powershell
cd "c:\Users\Administrador\OneDrive\Área de Trabalho\TesteDoProjetoPIM\ChatAiWeb\node-backend"
npm install
```

2. Configure environment

Create a `.env` file in the same folder (you can copy `.env.example`):

```
GEMINI_API_KEY=your_gemini_api_key_here
PORT=3000
```

Do NOT commit the `.env` with real keys to version control.

3. Run the server

```powershell
# in the same PowerShell session where you want the key available
$env:GEMINI_API_KEY='your_gemini_api_key_here'
# or create .env and the app will read it automatically
node server.js
```

4. Test the API

```powershell
# simple curl test
curl.exe -i -X POST "http://localhost:3000/api/chat" -H "Content-Type: application/json" -d "{ \"message\": \"Olá, teste\" }"

# or PowerShell Invoke-RestMethod
$body = @{ message = 'Olá, teste' } | ConvertTo-Json
Invoke-RestMethod -Uri "http://localhost:3000/api/chat" -Method Post -ContentType "application/json" -Body $body
```

5. Notes and security
- Keep your API key on the server only. Never put it in client-side JS.
- For production, prefer using a service account or OAuth-based auth for Google APIs instead of long-lived API keys.
- Add rate-limiting, authentication, and request validation before exposing this service publicly.
