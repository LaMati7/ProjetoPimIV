$base = 'http://localhost:5002'
$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession

Write-Output "Getting login page..."
$loginPage = Invoke-WebRequest "$base/Account/Login" -WebSession $session -UseBasicParsing
if ($null -eq $loginPage) { Write-Error 'Failed to fetch login page'; exit 1 }

$token = [System.Text.RegularExpressions.Regex]::Match($loginPage.Content,'name="__RequestVerificationToken".*?value="([^"]+)"').Groups[1].Value
Write-Output "Anti-forgery token length: $($token.Length)"

Write-Output "Posting login..."
$post = Invoke-WebRequest "$base/Account/LoginPost" -Method POST -WebSession $session -Body @{username='admin'; password='admin'; __RequestVerificationToken=$token} -UseBasicParsing -ErrorAction Stop
Write-Output "Login returned status: $($post.StatusCode)"

Write-Output "Requesting chat history..."
$history = Invoke-RestMethod "$base/api/chat/history?limit=10" -Method GET -WebSession $session -UseBasicParsing
Write-Output "History count: $($history.Count)"
$history | ConvertTo-Json -Depth 5

Write-Output "Checking DB file..."
$path = "c:\Users\Administrador\OneDrive\Área de Trabalho\TesteDoProjetoPIM\ChatAiWeb\chat_history.db"
if (Test-Path $path) { Write-Output "DB exists at: $path" } else { Write-Output "DB not found at: $path" }
