using Microsoft.Data.Sqlite;

var dbPath = args.Length > 0 ? args[0] : "c:\\Users\\Administrador\\OneDrive\\Área de Trabalho\\TesteDoProjetoPIM\\ChatAiWeb\\chat_history.db";
if (!System.IO.File.Exists(dbPath))
{
    Console.WriteLine($"DB file not found: {dbPath}");
    return 1;
}

var cs = $"Data Source={dbPath}";
using var conn = new SqliteConnection(cs);
conn.Open();

// Insert a test row to verify write permissions (created_by_test)
var insert = conn.CreateCommand();
insert.CommandText = "INSERT INTO ChatHistory (UserName, UserMessage, AiReply, CreatedAt) VALUES ($u,$m,$r,$c)";
insert.Parameters.AddWithValue("$u", "test_runner");
insert.Parameters.AddWithValue("$m", "Mensagem de teste gerada pelo verificador");
insert.Parameters.AddWithValue("$r", "Resposta de teste");
insert.Parameters.AddWithValue("$c", DateTime.UtcNow.ToString("o"));
try
{
    insert.ExecuteNonQuery();
    Console.WriteLine("Inserted test row into ChatHistory.");
}
catch (Exception ex)
{
    Console.WriteLine($"Insert failed: {ex.Message}");
}

var cmd = conn.CreateCommand();
cmd.CommandText = "SELECT Id, UserName, UserMessage, AiReply, CreatedAt FROM ChatHistory ORDER BY CreatedAt DESC LIMIT 20";

using var reader = cmd.ExecuteReader();
int count = 0;
while (reader.Read())
{
    count++;
    var id = reader.GetInt32(0);
    var user = reader.GetString(1);
    var msg  = reader.GetString(2);
    var reply = reader.GetString(3);
    var created = reader.GetString(4);
    Console.WriteLine($"[{id}] {created} - {user}\n  MSG: {msg}\n  REPLY: {reply}\n");
}

if (count == 0) Console.WriteLine("No rows found.");
return 0;
